#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>

#define CHUNK_SIZE       200     // debe coincidir o ser >= al del emisor
#define MAX_PACKETS      320     // ~64 kB máx (ajusta según necesidad)
#define MAX_IMAGE_SIZE   (CHUNK_SIZE * MAX_PACKETS)

typedef struct __attribute__((packed)) {
    uint16_t frame_id;
    uint16_t packet_id;
    uint16_t total_packets;
    uint16_t data_len;          // ≤ CHUNK_SIZE
    uint8_t  data[CHUNK_SIZE];
} image_packet_t;

uint8_t imageBuffer[MAX_IMAGE_SIZE];
bool    packetReceived[MAX_PACKETS];
uint16_t currentFrame      = 0xFFFF;   // valor imposible al inicio
uint16_t expectedPackets   = 0;
uint16_t receivedPackets   = 0;
size_t   completeImageSize = 0;

unsigned long lastPacketTime = 0;
#define FRAME_TIMEOUT_MS   1500   // si no llega paquete en 1.5 s se descarta el frame

AsyncWebServer server(80);               // Servidor web en puerto 80

//Datos Wi-Fi, cambiar a la red que se use durante las pruebas
const char* ssid     = "red-usada";         
const char* password = "contraseña-de-red"; 


//web, configurar los tiempos de autorecarga (actual en 500ms)
const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML><html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ESP32-CAM Imagen</title>
  <style>
    body { text-align:center; font-family:Arial; }
    img { max-width:100%; height:auto; }
  </style>
</head>
<body>
  <h2>Última imagen recibida</h2>
  <p><img src="/image.jpg" id="photo"></p>

  <script>
    setInterval(function() {
      var img = document.getElementById("photo");
      img.src = "/image.jpg?t=" + new Date().getTime();
    }, 500);
  </script>

</body>
</html>)rawliteral";

//void OnDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len) 
void OnDataRecv(const esp_now_recv_info_t *info, const uint8_t *incomingData, int len){
    if (len < (int)offsetof(image_packet_t, data)) {
        Serial.println("Paquete demasiado corto");
        return;
    }

    image_packet_t packet;
    // Copiamos solo lo seguro (cabecera + datos reales)
    size_t header_size = offsetof(image_packet_t, data);
    memcpy(&packet, incomingData, header_size);

    size_t safe_data_len = min((size_t)packet.data_len, (size_t)CHUNK_SIZE);
    safe_data_len = min(safe_data_len, (size_t)len - header_size);

    memcpy(packet.data, incomingData + header_size, safe_data_len);
    packet.data_len = safe_data_len;  // ajustamos por seguridad

    // Cambio de frame
    if (packet.frame_id != currentFrame) {
        if (currentFrame != 0xFFFF) {
            Serial.printf("Frame anterior incompleto: %u/%u\n", receivedPackets, expectedPackets);
        }
        currentFrame     = packet.frame_id;
        expectedPackets  = packet.total_packets;
        receivedPackets  = 0;
        memset(packetReceived, 0, sizeof(packetReceived));
        completeImageSize = 0;
        Serial.printf("Nuevo frame: %u  (esperando %u paquetes)\n", currentFrame, expectedPackets);
    }

    // Paquete válido?
    if (packet.packet_id >= expectedPackets || packet.packet_id >= MAX_PACKETS) {
        Serial.printf("Paquete fuera de rango: %u (max %u)\n", packet.packet_id, expectedPackets-1);
        return;
    }

    // Almacenar si no lo tenemos
    if (!packetReceived[packet.packet_id]) {
        size_t offset = (size_t)packet.packet_id * CHUNK_SIZE;
        memcpy(imageBuffer + offset, packet.data, packet.data_len);
        packetReceived[packet.packet_id] = true;
        receivedPackets++;

        lastPacketTime = millis();

        Serial.printf("Paq %3u/%u  (%4u bytes) → %u/%u\n",
                      packet.packet_id, expectedPackets-1, packet.data_len, receivedPackets, expectedPackets);

        lastPacketTime = millis();
    }

    // Imagen completa?
    if (receivedPackets >= expectedPackets && completeImageSize == 0) {
        completeImageSize = (size_t)expectedPackets * CHUNK_SIZE;
        completeImageSize -= CHUNK_SIZE;                    // quitar padding del último
        completeImageSize += packet.data_len;               // + tamaño real del último paquete
        // Ajustar por el último paquete que puede ser más pequeño

        Serial.printf("¡Imagen completa! Frame %u → %u bytes\n", currentFrame, completeImageSize);

        // Reset para próximo frame
        currentFrame = 0xFFFF;
        expectedPackets = 0;
        receivedPackets = 0;
    }
}

// Servir la página principal
void handleRoot(AsyncWebServerRequest *request) {
    request->send_P(200, "text/html", index_html);
}

// Servir la imagen JPEG (solo si ya está completa)
void handleImage(AsyncWebServerRequest *request) {
    if (completeImageSize == 0 || completeImageSize > MAX_IMAGE_SIZE) {
        request->send(404, "text/plain", "No hay imagen disponible");
        return;
    }

    request->send_P(200, "image/jpeg", imageBuffer, completeImageSize);
}

void setup() {
    Serial.begin(115200);
    delay(200);
    Serial.println("\nReceptor ESP-NOW iniciado...");

    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, password);
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    //esp_wifi_set_channel(1, WIFI_SECOND_CHAN_NONE);
    Serial.println("\nWiFi conectado → IP: " + WiFi.localIP().toString());
    Serial.print("Canal WiFi: ");//ver que canal estan usadando
    Serial.println(WiFi.channel());

    if (esp_now_init() != ESP_OK) {
        Serial.println("Error inicializando ESP-NOW");
        while(1) delay(1000);
    }

    esp_now_register_recv_cb(OnDataRecv);

    Serial.print("MAC propio: ");
    Serial.println(WiFi.macAddress());

    Serial.println("Esperando paquetes...");

    // Rutas del servidor web
    server.on("/", HTTP_GET, handleRoot);
    server.on("/image.jpg", HTTP_GET, handleImage);

    server.begin();
    Serial.println("Servidor web iniciado → abre http://" + WiFi.localIP().toString() + " en tu navegador");
}

void loop() {
    // Timeout de frame (evita quedar colgado si se pierden paquetes finales)
    if (currentFrame != 0xFFFF && millis() - lastPacketTime > FRAME_TIMEOUT_MS) {
        Serial.printf("Timeout frame %u → solo %u/%u paquetes\n", 
                      currentFrame, receivedPackets, expectedPackets);
        currentFrame = 0xFFFF;
        expectedPackets = 0;
        receivedPackets = 0;
        completeImageSize = 0;
    }

    delay(10);  
}
