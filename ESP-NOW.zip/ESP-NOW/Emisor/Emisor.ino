#include "esp_camera.h"
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>

#define CAMERA_MODEL_AI_THINKER
#include "camera_pins.h"

// Configuración del receptor     
uint8_t receiverMAC[] = {0xD4, 0xE9, 0xF4, 0xE8, 0x03, 0xB8};


// Estructura de cada paquete                 
#define CHUNK_SIZE 200           // Máximo recomendado ~236–240 para dejar espacio a cabecera
typedef struct __attribute__((packed)) {
    uint16_t frame_id;       // Número de foto (para detectar cambio de imagen)
    uint16_t packet_id;      // 
    uint16_t total_packets;  // Total de paquetes que componen esta imagen
    uint16_t data_len;       // Bytes válidos en este paquete (≤ CHUNK_SIZE)
    uint8_t  data[CHUNK_SIZE];      // ← ajustado para caber en ~250 bytes total
} image_packet_t;


#define SEND_DELAY_MS  15         // Pequeño retardo entre paquetes 

static uint16_t current_frame_id = 0;

bool sendESPNow(const uint8_t* mac, const void* data, size_t len) {
    esp_err_t result = esp_now_send(mac, (uint8_t*)data, len);
    if (result == ESP_OK) {
        return true;
    } else {
        Serial.printf("Error enviando ESP-NOW: %d\n", result);
        return false;
    }
}

void setup() {
    Serial.begin(115200);
    Serial.setDebugOutput(true);
    delay(100);
    Serial.println("\nIniciando ESP32-CAM Emisor...");

    // ── Configuración cámara ───────────────────────────────────────
    camera_config_t config;
    config.ledc_channel    = LEDC_CHANNEL_0;
    config.ledc_timer      = LEDC_TIMER_0;
    config.pin_d0          = Y2_GPIO_NUM;
    config.pin_d1          = Y3_GPIO_NUM;
    config.pin_d2          = Y4_GPIO_NUM;
    config.pin_d3          = Y5_GPIO_NUM;
    config.pin_d4          = Y6_GPIO_NUM;
    config.pin_d5          = Y7_GPIO_NUM;
    config.pin_d6          = Y8_GPIO_NUM;
    config.pin_d7          = Y9_GPIO_NUM;
    config.pin_xclk        = XCLK_GPIO_NUM;
    config.pin_pclk        = PCLK_GPIO_NUM;
    config.pin_vsync       = VSYNC_GPIO_NUM;
    config.pin_href        = HREF_GPIO_NUM;
    config.pin_sccb_sda    = SIOD_GPIO_NUM;
    config.pin_sccb_scl    = SIOC_GPIO_NUM;
    config.pin_pwdn        = PWDN_GPIO_NUM;
    config.pin_reset       = RESET_GPIO_NUM;
    config.xclk_freq_hz    = 20000000;
    config.pixel_format    = PIXFORMAT_JPEG;
    config.frame_size      = FRAMESIZE_QVGA;      // 
    config.jpeg_quality    = 20;                  // 10–63 (menor = mejor calidad)
    config.fb_count        = 2;
    config.grab_mode       = CAMERA_GRAB_LATEST;
    config.fb_location     = CAMERA_FB_IN_PSRAM;

    // Init camera
    esp_err_t err = esp_camera_init(&config);
    if (err != ESP_OK) {
        Serial.printf("Camera init failed with error 0x%x\n", err);
        while(1) delay(1000);
    }

    sensor_t *s = esp_camera_sensor_get();
    if (s->id.PID == OV3660_PID) {
        s->set_vflip(s, 1);
        s->set_brightness(s, 1);
        s->set_saturation(s, -2);
    }

    // Inicializar ESP-NOW 
    WiFi.mode(WIFI_STA);
    WiFi.setSleep(false);
    esp_wifi_set_channel(11, WIFI_SECOND_CHAN_NONE);// Recordar cambiar el canal en base al receptor

    if (esp_now_init() != ESP_OK) {
        Serial.println("Error inicializando ESP-NOW");
        while(1) delay(1000);
    }

    esp_now_peer_info_t peerInfo = {};
    memcpy(peerInfo.peer_addr, receiverMAC, 6);
    peerInfo.channel = 0;  
    peerInfo.encrypt = false;

    if (esp_now_add_peer(&peerInfo) != ESP_OK) {
        Serial.println("Error añadiendo peer");
        while(1) delay(1000);
    }

    Serial.println("ESP-NOW inicializado → listo para enviar");
    Serial.printf("MAC destino: %02X:%02X:%02X:%02X:%02X:%02X\n",
                  receiverMAC[0], receiverMAC[1], receiverMAC[2],
                  receiverMAC[3], receiverMAC[4], receiverMAC[5]);
}

void loop() {
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        Serial.println("Fallo al capturar imagen");
        delay(100);
        return;
    }

    Serial.printf("Imagen capturada → %u bytes  (QVGA JPEG)\n", fb->len);

    current_frame_id++;                     
    uint16_t total_packets = (fb->len + CHUNK_SIZE - 1) / CHUNK_SIZE;

    image_packet_t packet;
    packet.frame_id     = current_frame_id;
    packet.total_packets = total_packets;

    for (uint16_t i = 0; i < total_packets; i++) {
        packet.packet_id = i;

        size_t offset = i * CHUNK_SIZE;
        size_t remaining = fb->len - offset;
        packet.data_len = min((size_t)CHUNK_SIZE, remaining);

        memcpy(packet.data, fb->buf + offset, packet.data_len);

        size_t packet_size = sizeof(image_packet_t) - CHUNK_SIZE + packet.data_len;

        if (!sendESPNow(receiverMAC, &packet, packet_size)) {
            Serial.println("→ Envío fallido, reintentando próxima imagen...");
            break;
        }

        delay(SEND_DELAY_MS);   // evitar saturar ESP-NOW
    }

    esp_camera_fb_return(fb);

    delay(500);   // Tiempo entre fotos completas (ajusta para pruebas)
}